﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PrjAgingController.Class
{
    public delegate void HandleImageGroupCallback(int o_Index, MemoryStream o_ms);

    public class _st_HandleImageSeries_
    {
        public int Index;
        public int NeedCaptureCnt;
        public List<MemoryStream> ml_MemoryStream;

        public _st_HandleImageSeries_(
            int o_Index, int o_NeedCaptureCnt)
        {
            this.Index = o_Index;
            this.NeedCaptureCnt = o_NeedCaptureCnt;
            this.ml_MemoryStream = new List<MemoryStream> { };
        }
    }

    public class ClsMainProcess
    {
        private CommonBase.Logger.InfoManagerWinForm m_InfoManager;

        // Start app DateTime
        private DateTime m_StartApplicationDay;

        // config
        private ClsBootConfig m_ClsBootConfig = null;
        private ClsNetworkConfig m_ClsNetworkConfig = null;
               
        // control
        private ClsNetworkControl m_ClsNetworkControl = null;
        private ClsRecordControl m_ClsRecordControl = null;

        // 
        private string m_currentId;

        private List<_st_HandleImageSeries_> ml_st_HandleImageSeries_;

        //
        private bool m_IsStart = false;

        public ClsMainProcess(
            ClsBootConfig o_ClsBootConfig,
            CommonBase.Logger.InfoManagerWinForm o_InfoManager)
        {
            this.m_ClsBootConfig = o_ClsBootConfig;
            this.m_InfoManager = o_InfoManager;

            this.ml_st_HandleImageSeries_ = new List<_st_HandleImageSeries_> { };
        }

        private void funcCheckConfigExists()
        {

            // Network config
            if (!System.IO.File.Exists(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME))
            {
                ClsNetworkConfig temp_ClsNetworkConfig = new ClsNetworkConfig();
                temp_ClsNetworkConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME, true);
                this.m_InfoManager.HighLight("Network config is not exist, new one : " + Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);
            }

            //// Plc config
            //if (!File.Exists(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME))
            //{
            //    ClsPlcConfig temp_ClsPlcConfig = new ClsPlcConfig();
            //    temp_ClsPlcConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME, true);
            //    this.g_InfoManager.HighLight("Plc config is not exist, new one : " + Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME);
            //}

            //// Record config
            //if (!File.Exists(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME))
            //{
            //    ClsRecordConfig temp_ClsRecordConfig = new ClsRecordConfig();
            //    temp_ClsRecordConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME, true);
            //    this.g_InfoManager.HighLight("Record config is not exist, new one : " + Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME);
            //}

        }

        private void _threadToHandleQueue_()
        {

        }

        public void Initital()
        {
            try
            {
                this.funcCheckConfigExists();

                // start day
                this.m_StartApplicationDay = DateTime.Today;

                this.m_InfoManager.General("[App Version] : " + Common.AGING_CONTROLLER_APP_VERSION);
                this.m_InfoManager.General("[Initital] Start Day : " + this.m_StartApplicationDay.ToString("yyyyMMdd"));
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[Initital] error, " + ex.Message);
            }
        }

        public void StartDetect()
        {
            try
            {
                this.m_ClsNetworkConfig = new ClsNetworkConfig();
                if (System.IO.File.Exists(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME))
                {
                    this.m_ClsNetworkConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);
                }

                //
                for (int i = 0; i < this.ml_st_HandleImageSeries_.Count; i++)
                {
                    for (int j = 0; j < this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Count; j++)
                    {
                        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Flush();
                        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Close();
                        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Dispose();
                    }
                    this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Clear();
                }
                this.ml_st_HandleImageSeries_.Clear();

                //
                for (int i = 0; i < this.m_ClsNetworkConfig.ml_st_NetworkGroup_.Count; i++)
                {
                    if (this.m_ClsNetworkConfig.ml_st_NetworkGroup_[i].Enable)
                    {
                        _st_HandleImageSeries_ tmp_st_HandleImageSeries_ = new _st_HandleImageSeries_(i, 2);
                        this.ml_st_HandleImageSeries_.Add(tmp_st_HandleImageSeries_);
                    }
                }

                //
                this.m_ClsNetworkControl = new ClsNetworkControl(
                     this.m_ClsNetworkConfig,
                     this.m_InfoManager);
                this.m_ClsNetworkControl.m_HandleImageGroupCallback += new HandleImageGroupCallback(this.HandleImageGroup);

                this.m_ClsNetworkControl.StartServer();

                this.m_IsStart = true;


                this.m_currentId = DateTime.Now.ToString("HHmmss");


            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[StartDetect] error, " + ex.Message);
            }
        }

        public void StopDetect()
        {
            try
            {
                this.m_ClsNetworkControl.StopServer();

                this.m_IsStart = false;
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[StopDetect] error, " + ex.Message);
            }
        }

        public void CheckCurrentDate()
        {
            try
            {
                DateTime NowDay = DateTime.Today;

                TimeSpan ts1 = NowDay - this.m_StartApplicationDay;
                if (ts1.Days > 0)
                {
                    this.m_StartApplicationDay = NowDay;
                    this.m_ClsRecordControl.CheckCurrentDate(this.m_StartApplicationDay.ToString("yyyyMMdd"));

                    this.m_InfoManager.General("[Cross Day] : reset cnt");
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[CheckCurrentDate] error, " + ex.Message);
            }
        }

        //
        public bool IsStart()
        {
            return this.m_IsStart;
        }

        // event
        public void HandleImageGroup(int o_Index, MemoryStream o_ms)
        {
            Monitor.Enter(this);
            try
            {
                //
                string saveFolder = $"{this.m_ClsBootConfig.rootPath}\\Output\\" +
                    $"{this.m_StartApplicationDay.ToString("yyyyMMdd")}\\{this.m_currentId}\\{o_Index}";

                if (!System.IO.Directory.Exists(saveFolder))
                {
                    System.IO.Directory.CreateDirectory(saveFolder);
                }
                string savePath = saveFolder + "\\" + DateTime.Now.ToString("HHmmss") + "_img.jpeg";

                MemoryStream ms = new MemoryStream();

                o_ms.Seek(0, System.IO.SeekOrigin.Begin);
                o_ms.CopyTo(ms);

                this.ml_st_HandleImageSeries_[o_Index].ml_MemoryStream.Add(ms);
                this.m_InfoManager.General($"Add {o_Index}");

                bool isAllReceiveDone = true;
                for (int i = 0; i < this.ml_st_HandleImageSeries_.Count; i++)
                {
                    if (this.ml_st_HandleImageSeries_[i].NeedCaptureCnt !=
                        this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Count)
                    {
                        isAllReceiveDone = false;
                    }
                }

                if (isAllReceiveDone)
                {
                    this.m_InfoManager.General("HandleImageGroup all receive done");
                }
                //Image img = Image.FromStream(ms);
                //img.Save(savePath, ImageFormat.Jpeg);

                //this.m_InfoManager.General("HandleImageGroup : " + savePath + " OK!");
            }
            catch (Exception ex) 
            {
                this.m_InfoManager.Error($"[HandleImageGroup] index:{o_Index} error, " + ex.Message);
            }
            finally
            {
                Monitor.Exit(this);
            }
        }

        //
        public ClsNetworkConfig GetNetworkConfigObj()
        {
            return this.m_ClsNetworkConfig;
        }

        // 
        public void SendImageTest()
        {
            if (this.m_ClsNetworkControl == null ||
                !this.m_IsStart)
            {
                return;
            }

            try
            {
                //this.m_currentId = DateTime.Now.ToString("HHmmss");

                //for (int i = 0; i < this.ml_st_HandleImageSeries_.Count; i++)
                //{
                //    for (int j = 0; j < this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Count; j++)
                //    {
                //        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Flush();
                //        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Close();
                //        this.ml_st_HandleImageSeries_[i].ml_MemoryStream[j].Dispose();
                //    }
                //    this.ml_st_HandleImageSeries_[i].ml_MemoryStream.Clear();
                //}

                //
                this.m_ClsNetworkControl.SendImage();


            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("[SendImageTest] error, " + ex.Message);
            }
        }



    }
}
