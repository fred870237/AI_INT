﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjAgingController.Class
{
    public partial class ClsRecipeConfig : CommonBase.Config.BaseConfig<ClsRecipeConfig>
    {
        private string classVersion = "ClsRecipeConfig_202205171001";

        public string ModelName;
        public string CreateTime;

        ClsRecipeConfig()
        {
            this.ModelName = "DefaultModel";
            this.CreateTime = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
        }

        protected override bool CheckValue(ClsRecipeConfig tmpConfig)
        {
            this.ModelName = tmpConfig.ModelName;

            this.CreateTime = tmpConfig.CreateTime;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }


    }

    public class ClsRecipeControl
    {




    }

}
