﻿
namespace PrjAgingController
{
    partial class frmAgingController
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.skinningManager1 = new SkinFramework.SkinningManager();
            this.btnSendImage = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpLogSystem = new System.Windows.Forms.TabPage();
            this.rtfLogSystem = new System.Windows.Forms.RichTextBox();
            this.tpLogNet = new System.Windows.Forms.TabPage();
            this.rtfLogNet = new System.Windows.Forms.RichTextBox();
            this.tpLogWarning = new System.Windows.Forms.TabPage();
            this.rtfLogWarning = new System.Windows.Forms.RichTextBox();
            this.tpLogError = new System.Windows.Forms.TabPage();
            this.rtfLogError = new System.Windows.Forms.RichTextBox();
            this.tpLogDebug = new System.Windows.Forms.TabPage();
            this.rtfLogDebug = new System.Windows.Forms.RichTextBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.dtpNowDate = new System.Windows.Forms.DateTimePicker();
            this.btnStart = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnLoadImage = new System.Windows.Forms.Button();
            this.tclGlassInfo = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgvGlassInfo = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dgvGlassInfoHistory = new System.Windows.Forms.DataGridView();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.lblModelName = new System.Windows.Forms.Label();
            this.tclImageSeries = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pnlImageSeries = new System.Windows.Forms.Panel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.pnlScaleImage = new System.Windows.Forms.Panel();
            this.picScaleImage = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmiLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.NetworkConfigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tmrAlive = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tpLogSystem.SuspendLayout();
            this.tpLogNet.SuspendLayout();
            this.tpLogWarning.SuspendLayout();
            this.tpLogError.SuspendLayout();
            this.tpLogDebug.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tclGlassInfo.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGlassInfo)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGlassInfoHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.tclImageSeries.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).BeginInit();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.pnlScaleImage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picScaleImage)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // skinningManager1
            // 
            this.skinningManager1.DefaultSkin = SkinFramework.DefaultSkin.Office2007Obsidian;
            this.skinningManager1.ParentForm = this;
            // 
            // btnSendImage
            // 
            this.btnSendImage.AutoSize = true;
            this.btnSendImage.Enabled = false;
            this.btnSendImage.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendImage.Location = new System.Drawing.Point(10, 92);
            this.btnSendImage.Margin = new System.Windows.Forms.Padding(4);
            this.btnSendImage.Name = "btnSendImage";
            this.btnSendImage.Size = new System.Drawing.Size(100, 50);
            this.btnSendImage.TabIndex = 2;
            this.btnSendImage.Text = "Send\r\nImage";
            this.btnSendImage.UseVisualStyleBackColor = true;
            this.btnSendImage.Click += new System.EventHandler(this.btnSendImage_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpLogSystem);
            this.tabControl1.Controls.Add(this.tpLogNet);
            this.tabControl1.Controls.Add(this.tpLogWarning);
            this.tabControl1.Controls.Add(this.tpLogError);
            this.tabControl1.Controls.Add(this.tpLogDebug);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(640, 181);
            this.tabControl1.TabIndex = 3;
            // 
            // tpLogSystem
            // 
            this.tpLogSystem.Controls.Add(this.rtfLogSystem);
            this.tpLogSystem.Location = new System.Drawing.Point(4, 25);
            this.tpLogSystem.Name = "tpLogSystem";
            this.tpLogSystem.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogSystem.Size = new System.Drawing.Size(632, 152);
            this.tpLogSystem.TabIndex = 0;
            this.tpLogSystem.Text = "System";
            this.tpLogSystem.UseVisualStyleBackColor = true;
            // 
            // rtfLogSystem
            // 
            this.rtfLogSystem.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogSystem.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtfLogSystem.Location = new System.Drawing.Point(3, 3);
            this.rtfLogSystem.Name = "rtfLogSystem";
            this.rtfLogSystem.Size = new System.Drawing.Size(626, 146);
            this.rtfLogSystem.TabIndex = 2;
            this.rtfLogSystem.Text = "";
            // 
            // tpLogNet
            // 
            this.tpLogNet.Controls.Add(this.rtfLogNet);
            this.tpLogNet.Location = new System.Drawing.Point(4, 25);
            this.tpLogNet.Name = "tpLogNet";
            this.tpLogNet.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogNet.Size = new System.Drawing.Size(630, 151);
            this.tpLogNet.TabIndex = 1;
            this.tpLogNet.Text = "Net";
            this.tpLogNet.UseVisualStyleBackColor = true;
            // 
            // rtfLogNet
            // 
            this.rtfLogNet.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogNet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtfLogNet.Location = new System.Drawing.Point(3, 3);
            this.rtfLogNet.Name = "rtfLogNet";
            this.rtfLogNet.Size = new System.Drawing.Size(624, 145);
            this.rtfLogNet.TabIndex = 3;
            this.rtfLogNet.Text = "";
            // 
            // tpLogWarning
            // 
            this.tpLogWarning.Controls.Add(this.rtfLogWarning);
            this.tpLogWarning.Location = new System.Drawing.Point(4, 25);
            this.tpLogWarning.Name = "tpLogWarning";
            this.tpLogWarning.Size = new System.Drawing.Size(630, 151);
            this.tpLogWarning.TabIndex = 2;
            this.tpLogWarning.Text = "Warning";
            this.tpLogWarning.UseVisualStyleBackColor = true;
            // 
            // rtfLogWarning
            // 
            this.rtfLogWarning.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogWarning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtfLogWarning.Location = new System.Drawing.Point(0, 0);
            this.rtfLogWarning.Name = "rtfLogWarning";
            this.rtfLogWarning.Size = new System.Drawing.Size(630, 151);
            this.rtfLogWarning.TabIndex = 4;
            this.rtfLogWarning.Text = "";
            // 
            // tpLogError
            // 
            this.tpLogError.Controls.Add(this.rtfLogError);
            this.tpLogError.Location = new System.Drawing.Point(4, 25);
            this.tpLogError.Name = "tpLogError";
            this.tpLogError.Size = new System.Drawing.Size(630, 151);
            this.tpLogError.TabIndex = 3;
            this.tpLogError.Text = "Error";
            this.tpLogError.UseVisualStyleBackColor = true;
            // 
            // rtfLogError
            // 
            this.rtfLogError.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogError.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtfLogError.Location = new System.Drawing.Point(0, 0);
            this.rtfLogError.Name = "rtfLogError";
            this.rtfLogError.Size = new System.Drawing.Size(630, 151);
            this.rtfLogError.TabIndex = 5;
            this.rtfLogError.Text = "";
            // 
            // tpLogDebug
            // 
            this.tpLogDebug.Controls.Add(this.rtfLogDebug);
            this.tpLogDebug.Location = new System.Drawing.Point(4, 25);
            this.tpLogDebug.Name = "tpLogDebug";
            this.tpLogDebug.Size = new System.Drawing.Size(630, 151);
            this.tpLogDebug.TabIndex = 4;
            this.tpLogDebug.Text = "Debug";
            this.tpLogDebug.UseVisualStyleBackColor = true;
            // 
            // rtfLogDebug
            // 
            this.rtfLogDebug.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogDebug.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtfLogDebug.Location = new System.Drawing.Point(0, 0);
            this.rtfLogDebug.Name = "rtfLogDebug";
            this.rtfLogDebug.Size = new System.Drawing.Size(630, 151);
            this.rtfLogDebug.TabIndex = 5;
            this.rtfLogDebug.Text = "";
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 30);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.splitContainer3);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer2.Size = new System.Drawing.Size(1418, 753);
            this.splitContainer2.SplitterDistance = 381;
            this.splitContainer2.TabIndex = 5;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.dtpNowDate);
            this.splitContainer3.Panel1.Controls.Add(this.btnStart);
            this.splitContainer3.Panel1.Controls.Add(this.textBox1);
            this.splitContainer3.Panel1.Controls.Add(this.btnLoadImage);
            this.splitContainer3.Panel1.Controls.Add(this.btnSendImage);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.tclGlassInfo);
            this.splitContainer3.Size = new System.Drawing.Size(381, 753);
            this.splitContainer3.SplitterDistance = 241;
            this.splitContainer3.TabIndex = 0;
            // 
            // dtpNowDate
            // 
            this.dtpNowDate.CalendarFont = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNowDate.Location = new System.Drawing.Point(116, 10);
            this.dtpNowDate.Name = "dtpNowDate";
            this.dtpNowDate.Size = new System.Drawing.Size(161, 26);
            this.dtpNowDate.TabIndex = 6;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Green;
            this.btnStart.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(10, 10);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 75);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(234, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 4;
            // 
            // btnLoadImage
            // 
            this.btnLoadImage.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadImage.Location = new System.Drawing.Point(234, 81);
            this.btnLoadImage.Name = "btnLoadImage";
            this.btnLoadImage.Size = new System.Drawing.Size(112, 31);
            this.btnLoadImage.TabIndex = 3;
            this.btnLoadImage.Text = "Load Image";
            this.btnLoadImage.UseVisualStyleBackColor = true;
            this.btnLoadImage.Click += new System.EventHandler(this.btnLoadImage_Click);
            // 
            // tclGlassInfo
            // 
            this.tclGlassInfo.Controls.Add(this.tabPage5);
            this.tclGlassInfo.Controls.Add(this.tabPage6);
            this.tclGlassInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tclGlassInfo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tclGlassInfo.Location = new System.Drawing.Point(0, 0);
            this.tclGlassInfo.Name = "tclGlassInfo";
            this.tclGlassInfo.SelectedIndex = 0;
            this.tclGlassInfo.Size = new System.Drawing.Size(377, 504);
            this.tclGlassInfo.TabIndex = 1;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dgvGlassInfo);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(369, 475);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Inline";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dgvGlassInfo
            // 
            this.dgvGlassInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGlassInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGlassInfo.Location = new System.Drawing.Point(3, 3);
            this.dgvGlassInfo.Name = "dgvGlassInfo";
            this.dgvGlassInfo.Size = new System.Drawing.Size(363, 469);
            this.dgvGlassInfo.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dgvGlassInfoHistory);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(369, 475);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "History";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dgvGlassInfoHistory
            // 
            this.dgvGlassInfoHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGlassInfoHistory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGlassInfoHistory.Location = new System.Drawing.Point(3, 3);
            this.dgvGlassInfoHistory.Name = "dgvGlassInfoHistory";
            this.dgvGlassInfoHistory.Size = new System.Drawing.Size(363, 469);
            this.dgvGlassInfoHistory.TabIndex = 1;
            // 
            // splitContainer4
            // 
            this.splitContainer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.splitContainer5);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.splitContainer6);
            this.splitContainer4.Size = new System.Drawing.Size(1033, 753);
            this.splitContainer4.SplitterDistance = 385;
            this.splitContainer4.TabIndex = 0;
            // 
            // splitContainer5
            // 
            this.splitContainer5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.lblModelName);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.tclImageSeries);
            this.splitContainer5.Size = new System.Drawing.Size(385, 753);
            this.splitContainer5.SplitterDistance = 138;
            this.splitContainer5.TabIndex = 0;
            // 
            // lblModelName
            // 
            this.lblModelName.AutoSize = true;
            this.lblModelName.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelName.ForeColor = System.Drawing.Color.OrangeRed;
            this.lblModelName.Location = new System.Drawing.Point(10, 10);
            this.lblModelName.Name = "lblModelName";
            this.lblModelName.Size = new System.Drawing.Size(193, 24);
            this.lblModelName.TabIndex = 0;
            this.lblModelName.Text = "Model Name : None";
            // 
            // tclImageSeries
            // 
            this.tclImageSeries.Controls.Add(this.tabPage3);
            this.tclImageSeries.Controls.Add(this.tabPage4);
            this.tclImageSeries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tclImageSeries.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tclImageSeries.Location = new System.Drawing.Point(0, 0);
            this.tclImageSeries.Name = "tclImageSeries";
            this.tclImageSeries.SelectedIndex = 0;
            this.tclImageSeries.Size = new System.Drawing.Size(381, 607);
            this.tclImageSeries.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pnlImageSeries);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(373, 578);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "P0";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pnlImageSeries
            // 
            this.pnlImageSeries.BackColor = System.Drawing.Color.Silver;
            this.pnlImageSeries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlImageSeries.Location = new System.Drawing.Point(3, 3);
            this.pnlImageSeries.Name = "pnlImageSeries";
            this.pnlImageSeries.Size = new System.Drawing.Size(367, 572);
            this.pnlImageSeries.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(371, 575);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "P1";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // splitContainer6
            // 
            this.splitContainer6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(0, 0);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer6.Size = new System.Drawing.Size(644, 753);
            this.splitContainer6.SplitterDistance = 564;
            this.splitContainer6.TabIndex = 0;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.pnlScaleImage);
            this.splitContainer1.Size = new System.Drawing.Size(644, 564);
            this.splitContainer1.SplitterDistance = 138;
            this.splitContainer1.TabIndex = 0;
            // 
            // pnlScaleImage
            // 
            this.pnlScaleImage.Controls.Add(this.picScaleImage);
            this.pnlScaleImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlScaleImage.Location = new System.Drawing.Point(0, 0);
            this.pnlScaleImage.Name = "pnlScaleImage";
            this.pnlScaleImage.Size = new System.Drawing.Size(640, 418);
            this.pnlScaleImage.TabIndex = 2;
            // 
            // picScaleImage
            // 
            this.picScaleImage.BackColor = System.Drawing.SystemColors.ControlText;
            this.picScaleImage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.picScaleImage.Location = new System.Drawing.Point(0, 0);
            this.picScaleImage.Name = "picScaleImage";
            this.picScaleImage.Size = new System.Drawing.Size(640, 418);
            this.picScaleImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picScaleImage.TabIndex = 1;
            this.picScaleImage.TabStop = false;
            this.picScaleImage.Paint += new System.Windows.Forms.PaintEventHandler(this.picScaleImage_Paint);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 786);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1424, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Control;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuStrip1.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiLogin,
            this.tsmiConfig,
            this.tsmiAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1424, 27);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmiLogin
            // 
            this.tsmiLogin.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.tsmiLogin.Name = "tsmiLogin";
            this.tsmiLogin.Size = new System.Drawing.Size(92, 23);
            this.tsmiLogin.Text = "登入 Login in";
            this.tsmiLogin.Click += new System.EventHandler(this.tsmiLogin_Click);
            // 
            // tsmiConfig
            // 
            this.tsmiConfig.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NetworkConfigToolStripMenuItem});
            this.tsmiConfig.Name = "tsmiConfig";
            this.tsmiConfig.Size = new System.Drawing.Size(109, 23);
            this.tsmiConfig.Text = "參數設定 Config";
            // 
            // NetworkConfigToolStripMenuItem
            // 
            this.NetworkConfigToolStripMenuItem.Name = "NetworkConfigToolStripMenuItem";
            this.NetworkConfigToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.NetworkConfigToolStripMenuItem.Text = "網路設定 Network Config";
            this.NetworkConfigToolStripMenuItem.Click += new System.EventHandler(this.NetworkConfigToolStripMenuItem_Click);
            // 
            // tsmiAbout
            // 
            this.tsmiAbout.Name = "tsmiAbout";
            this.tsmiAbout.Size = new System.Drawing.Size(82, 23);
            this.tsmiAbout.Text = "關於 About";
            this.tsmiAbout.Click += new System.EventHandler(this.tsmiAbout_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.statusStrip1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.menuStrip1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.splitContainer2, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 3.435115F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 96.56489F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1424, 808);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // tmrAlive
            // 
            this.tmrAlive.Interval = 1000;
            this.tmrAlive.Tick += new System.EventHandler(this.tmrAlive_Tick);
            // 
            // frmAgingController
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1424, 808);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmAgingController";
            this.Text = "AgingController";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AgingController_FormClosed);
            this.Load += new System.EventHandler(this.AgingController_Load);
            this.tabControl1.ResumeLayout(false);
            this.tpLogSystem.ResumeLayout(false);
            this.tpLogNet.ResumeLayout(false);
            this.tpLogWarning.ResumeLayout(false);
            this.tpLogError.ResumeLayout(false);
            this.tpLogDebug.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tclGlassInfo.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGlassInfo)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGlassInfoHistory)).EndInit();
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            this.splitContainer5.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.tclImageSeries.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer6)).EndInit();
            this.splitContainer6.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.pnlScaleImage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picScaleImage)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private SkinFramework.SkinningManager skinningManager1;
        private System.Windows.Forms.Button btnSendImage;
        private System.Windows.Forms.PictureBox picScaleImage;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpLogSystem;
        private System.Windows.Forms.RichTextBox rtfLogSystem;
        private System.Windows.Forms.TabPage tpLogNet;
        private System.Windows.Forms.RichTextBox rtfLogNet;
        private System.Windows.Forms.TabPage tpLogWarning;
        private System.Windows.Forms.RichTextBox rtfLogWarning;
        private System.Windows.Forms.TabPage tpLogError;
        private System.Windows.Forms.RichTextBox rtfLogError;
        private System.Windows.Forms.TabPage tpLogDebug;
        private System.Windows.Forms.RichTextBox rtfLogDebug;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiLogin;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TabControl tclImageSeries;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgvGlassInfo;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TabControl tclGlassInfo;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel pnlScaleImage;
        private System.Windows.Forms.DataGridView dgvGlassInfoHistory;
        private System.Windows.Forms.Button btnLoadImage;
        private System.Windows.Forms.ToolStripMenuItem tsmiConfig;
        private System.Windows.Forms.ToolStripMenuItem tsmiAbout;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel pnlImageSeries;
        private System.Windows.Forms.ToolStripMenuItem NetworkConfigToolStripMenuItem;
        private System.Windows.Forms.Label lblModelName;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer tmrAlive;
        private System.Windows.Forms.DateTimePicker dtpNowDate;
    }
}

