﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;

using PrjAgingController.Class;

using System.Runtime.InteropServices;

namespace PrjAgingController
{

    public partial class frmAgingController : Form
    {
        // Log
        private CommonBase.Logger.InfoManagerWinForm g_InfoManager;

        // Config
        private ClsBootConfig g_ClsBootConfig = null;

        // Control
        private ClsMainProcess g_ClsMainProcess = null;


        // Form
        private frmAbout g_frmAbout = null;
        private frmNetworkConfig g_frmNetworkConfig = null;

        public frmAgingController()
        {
            InitializeComponent();
        }

        private void AgingController_Load(object sender, EventArgs e)
        {
            this.Text = Common.AGING_CONTROLLER_APP_VERSION;

            // boot config
            this.g_ClsBootConfig = new ClsBootConfig();
            if (File.Exists(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME))
            {
                try
                {
                    this.g_ClsBootConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    this.g_ClsBootConfig.ReadWithoutCrypto(Common.DEFAULT_CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                }
                this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
            }
            else
            {
                try
                {
                    string temp_BootConfigFolder = Path.GetDirectoryName(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                    if (!Directory.Exists(temp_BootConfigFolder))
                    {
                        Directory.CreateDirectory(temp_BootConfigFolder);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Create BootConfig folder fail");
                }

                this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
            }


            // log 
            // controller
            try
            {
                this.g_InfoManager = new CommonBase.Logger.InfoManagerWinForm(
                    this.g_ClsBootConfig.rootPath + "\\Log\\systemlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\networklog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\warninglog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\errorlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\debuglog");

                this.g_InfoManager.SetGeneralTextBox(ref this.rtfLogSystem);
                this.g_InfoManager.SetNetworkTextBox(ref this.rtfLogNet);
                this.g_InfoManager.SetWarningTextBox(ref this.rtfLogWarning);
                this.g_InfoManager.SetErrorTextBox(ref this.rtfLogError);
                this.g_InfoManager.SetDebugTextBox(ref this.rtfLogDebug);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

            // Title Style
            SkinFramework.DefaultSkin skin = SkinFramework.DefaultSkin.Office2007Obsidian;
            skinningManager1.DefaultSkin = skin;

            // frm Config
            try
            {
                //this.g_frmPlcConfig = new frmPlcConfig(this.g_ClsPlcConfig, this.g_InfoManager);
                this.g_frmNetworkConfig = new frmNetworkConfig(this.g_InfoManager);
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

            // main process
            try
            {
                this.g_ClsMainProcess = new ClsMainProcess(
                    this.g_ClsBootConfig,
                    this.g_InfoManager);

                this.g_ClsMainProcess.Initital();
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("[AgingController_Load] initial main process error, " + ex.Message);
            }
        }

        private void btnSendImage_Click(object sender, EventArgs e)
        {
            try
            {
                this.g_ClsMainProcess.SendImageTest();
            }
            catch (Exception ex)
            {

            }
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            string tmpStr = @"D:\NB_FV\Recipe\ip\B156XTN08_V1\align10.bmp";
            System.IO.FileStream fs = System.IO.File.OpenRead(tmpStr);
            picScaleImage.Image = Image.FromStream(fs);
            fs.Close();
        }

        private void picScaleImage_Paint(object sender, PaintEventArgs e)
        {
            //this.g_InfoManager.Error("picScaleImage_Paint");

        }

        private void AgingController_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null) this.g_InfoManager.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            System.Environment.Exit(0);
        }

        private void tsmiLogin_Click(object sender, EventArgs e)
        {

        }

        private void NetworkConfigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_frmNetworkConfig == null)
                {
                    this.g_frmNetworkConfig = new frmNetworkConfig(this.g_InfoManager);
                }
                this.g_frmNetworkConfig.UpdateObject(this.g_ClsMainProcess.GetNetworkConfigObj());

                if (!this.g_frmNetworkConfig.Visible)
                {
                    // Add the message
                    this.g_frmNetworkConfig.Show();
                }
                else
                {
                    this.g_frmNetworkConfig.WindowState = FormWindowState.Normal;
                    // Top
                    this.g_frmNetworkConfig.BringToFront();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void tsmiAbout_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_frmAbout == null)
                {
                    this.g_frmAbout = new frmAbout();
                }

                if (!this.g_frmAbout.Visible)
                {
                    // Add the message
                    this.g_frmAbout.Show();
                }
                else
                {
                    this.g_frmAbout.WindowState = FormWindowState.Normal;
                    // Top
                    this.g_frmAbout.BringToFront();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                //
                if (this.g_ClsMainProcess == null)
                {
                    this.g_ClsMainProcess = new ClsMainProcess(
                        this.g_ClsBootConfig,
                        this.g_InfoManager);

                    this.g_ClsMainProcess.Initital();
                }

                //
                if (!this.g_ClsMainProcess.IsStart())
                {
                    this.g_ClsMainProcess.StartDetect();

                    this.btnStart.Text = "Stop";
                    this.btnStart.BackColor = Color.Red;
                    this.btnSendImage.Enabled = true;
                }
                else
                {
                    this.g_ClsMainProcess.StopDetect();

                    this.btnStart.Text = "Start";
                    this.btnStart.BackColor = Color.Green;
                    this.btnSendImage.Enabled = false;
                }

            }
            catch (Exception ex)
            {

            }

        }

        private void tmrAlive_Tick(object sender, EventArgs e)
        {
            try
            {
                //

                //
                this.g_ClsMainProcess.CheckCurrentDate();

                //

            }
            catch (Exception ex)
            {

            }
        }
    }
}
