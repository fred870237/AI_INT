﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrjAgingController.Class;

namespace PrjAgingController
{
    public partial class frmNetworkConfig : Form
    {
        private ClsNetworkConfig m_ClsNetworkConfig;
        private ClsNetworkConfig m_ClsNetworkConfigInline;
        private CommonBase.Logger.InfoManager m_InfoManager;

        public frmNetworkConfig(
            CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsNetworkConfig = null;

            this.m_InfoManager = o_InfoManager;

            InitializeComponent();
        }

        public void UpdateObject(Class.ClsNetworkConfig o_ClsNetworkConfig)
        {
            this.m_ClsNetworkConfigInline = o_ClsNetworkConfig;
        }

        private void OnSaveConfig(object sender, EventArgs e)
        {
            if (this.m_ClsNetworkConfigInline != null)
            {
                this.m_ClsNetworkConfigInline.UpdateParams(this.m_ClsNetworkConfig);
            }

            this.m_ClsNetworkConfig.m_ClientWidth = this.ClientSize.Width;
            this.m_ClsNetworkConfig.m_ClientHeight = this.ClientSize.Height;

            this.m_ClsNetworkConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME, true);
            //MessageBox.Show(String.Format("參數儲存完畢[{0}]", Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME));
        }

        private void funcAddButton()
        {
            ToolStripButton objButton = null;

            foreach (Control objControl in this.propertyGrid1.Controls)
            {
                ToolStrip objToolStrip = objControl as ToolStrip;

                if (objToolStrip != null)
                {

                    //for (int i = 0; i < objToolStrip.Items.Count; i++)
                    //{
                    //    objToolStrip.Items[i].Visible = false;
                    //}

                    objButton = new ToolStripButton
                    {
                        CheckOnClick = false,
                        DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image,
                        Image = Properties.Resources.Save,
                        Name = "btnSave",
                        Size = new System.Drawing.Size(23, 22),
                        Text = "儲存參數",
                        ToolTipText = "儲存參數"
                    };
                    objButton.Click += new EventHandler(this.OnSaveConfig);
                    objToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { objButton });
                }
            }
        }

        private void frmNetworkConfig_Load(object sender, EventArgs e)
        {

            if (!System.IO.File.Exists(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME))
            {
                ClsNetworkConfig temp_ClsNetworkConfig = new ClsNetworkConfig();
                temp_ClsNetworkConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME, true);
                this.m_InfoManager.HighLight("Network config not exist, new one : " + Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);
            }

            this.m_ClsNetworkConfig = new ClsNetworkConfig();
            this.m_ClsNetworkConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);

            this.propertyGrid1.SelectedObject = this.m_ClsNetworkConfig;
            this.propertyGrid1.PropertySort = PropertySort.Categorized;

            this.funcAddButton();

            this.propertyGrid1.ExpandAllGridItems();

            //              
            this.ClientSize = new System.Drawing.Size(
                this.m_ClsNetworkConfig.m_ClientWidth,
                this.m_ClsNetworkConfig.m_ClientHeight);

        }

        private void frmNetworkConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }


    }
}
